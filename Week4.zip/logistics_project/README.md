# Predictive Modeling and Optimization of Delivery Times in an E-commerce Logistics System

Week 4 internship task: predict shipment delivery time (hours) with Python and test simple optimization ideas.

> **All data is SIMULATED** (fixed random seed 42). It contains no real company records.

## Installation
```bash
pip install -r requirements.txt
```
Tested with Python 3.12.3, NumPy 2.4.4, pandas 3.0.2, scikit-learn 1.8.0, Matplotlib 3.10.8. Minimum versions in `requirements.txt` were not tested on older releases.

## Run
```bash
python logistics_prediction.py
```
This regenerates every CSV, the saved model and all six charts next to the script.

## Files
| File | Description |
|---|---|
| `logistics_prediction.py` | Complete source code |
| `logistics_dataset_raw.csv` | 1,010 simulated rows with injected issues (25 missing weights, 15 missing traffic levels, 10 duplicates) |
| `logistics_dataset.csv` | 1,000 cleaned rows (duplicates removed; remaining gaps imputed inside the pipeline) |
| `eda_summary_statistics.csv` | Summary statistics |
| `model_evaluation_results.csv` | Test and 5-fold CV metrics for 5 models |
| `predictions.csv` | Actual vs predicted times for the 200 test shipments |
| `feature_importance.csv` | Tuned Random Forest importances |
| `optimization_results.csv` | Baseline and what-if scenarios (simulated predictions) |
| `results_summary.json` | Numbers used in the report |
| `best_model.joblib` | Saved selected model (Linear Regression pipeline) |
| `visualizations/` | Six PNG charts (fig1-fig6) |

## Method
Generate data -> clean (duplicates, missing values) -> one-hot encode -> 80/20 split -> train Linear Regression, Decision Tree, Random Forest -> grid-search tuning with 5-fold CV -> evaluate with MAE, RMSE, R² -> what-if analysis. Preprocessing is inside a scikit-learn Pipeline to avoid data leakage.

## Key results (test set, 200 shipments)
| Model | MAE (h) | RMSE (h) | R² |
|---|---|---|---|
| **Linear Regression (selected)** | 1.430 | 1.773 | 0.960 |
| Decision Tree | 2.150 | 2.844 | 0.897 |
| Random Forest | 1.754 | 2.232 | 0.937 |
| Decision Tree (tuned) | 2.141 | 2.882 | 0.894 |
| Random Forest (tuned) | 1.743 | 2.219 | 0.937 |

Model chosen by lowest cross-validated RMSE on training data. Linear Regression wins because the simulated target is mostly additive; this may not hold on real data.

**What-if (simulated):** capping dispatch delay at 1 hour lowers mean predicted delivery time from 22.42 h to 21.19 h (-5.5%). These are model predictions under assumptions (36 h promise window, INR 25 per shipment-hour), **not verified improvements**.

## Limitations
Simulated data with a known formula: scores do not show real-world performance. Only 200 test rows; random (not time-based) split.
