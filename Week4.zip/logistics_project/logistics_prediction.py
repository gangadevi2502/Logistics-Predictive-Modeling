"""
Predictive Modeling and Optimization of Delivery Times in an E-commerce
Logistics System Using Python  (Week 4 Internship Task)

NOTE: The dataset is SIMULATED with a fixed random seed. It does NOT contain
records from any real company.

Run:  python logistics_prediction.py
All outputs are written next to this script.
"""
import os
import json
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")                      # draw charts without a screen
import matplotlib.pyplot as plt
import joblib

from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import (GridSearchCV, KFold, cross_validate,
                                     train_test_split)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeRegressor

warnings.filterwarnings("ignore")
SEED = 42
BASE = os.path.dirname(os.path.abspath(__file__))
VIZ = os.path.join(BASE, "visualizations")
os.makedirs(VIZ, exist_ok=True)
SUMMARY = {}                               # numbers reused in the report

NUM_COLS = ["distance_km", "dispatch_delay_hours", "shipment_weight_kg",
            "num_packages"]
CAT_COLS = ["traffic_level", "weather_condition", "delivery_method"]
TARGET = "actual_delivery_time_hours"


# ---------------------------------------------------------------------------
# STEP 1: DATASET GENERATION (simulated, reproducible)
# ---------------------------------------------------------------------------
def generate_dataset(n=1000, seed=SEED):
    """Create n simulated shipments. Delivery time is built from a formula
    plus random noise, so the relationships are known and realistic."""
    rng = np.random.default_rng(seed)
    distance = np.clip(rng.gamma(2.0, 130.0, n), 5, 1500).round(1)
    delay = np.clip(rng.exponential(2.0, n), 0, 12).round(2)
    weight = np.clip(rng.lognormal(1.8, 0.8, n), 0.5, 60).round(2)
    packages = np.clip(rng.poisson(2.0, n) + 1, 1, 10)
    traffic = rng.choice(["Low", "Medium", "High"], n, p=[0.35, 0.45, 0.20])
    weather = rng.choice(["Clear", "Rain", "Storm"], n, p=[0.60, 0.30, 0.10])
    method = rng.choice(["Standard", "Express", "Economy"], n,
                        p=[0.50, 0.25, 0.25])

    traffic_mult = pd.Series(traffic).map(
        {"Low": 1.00, "Medium": 1.10, "High": 1.25}).to_numpy()
    weather_mult = pd.Series(weather).map(
        {"Clear": 1.00, "Rain": 1.08, "Storm": 1.20}).to_numpy()
    method_add = pd.Series(method).map(
        {"Express": -3.0, "Standard": 0.0, "Economy": 5.0}).to_numpy()
    noise = rng.normal(0, 1.5, n)

    # Target: base handling time + travel time (slowed by traffic/weather)
    #         + dispatch delay + small weight/package effects + method + noise
    time = (8.0 + 0.04 * distance * traffic_mult * weather_mult
            + 0.9 * delay + 0.04 * weight + 0.25 * packages
            + method_add + noise)
    time = np.clip(time, 2.0, None).round(2)

    return pd.DataFrame({
        "shipment_id": [f"SHP{i:04d}" for i in range(1, n + 1)],
        "distance_km": distance, "dispatch_delay_hours": delay,
        "traffic_level": traffic, "weather_condition": weather,
        "shipment_weight_kg": weight, "delivery_method": method,
        "num_packages": packages, TARGET: time})


def add_data_quality_issues(df, seed=SEED):
    """Deliberately inject 25 missing weights, 15 missing traffic levels and
    10 duplicate rows so that the cleaning step has something to demonstrate."""
    rng = np.random.default_rng(seed + 1)
    raw = df.copy()
    raw.loc[rng.choice(raw.index, 25, replace=False), "shipment_weight_kg"] = np.nan
    raw.loc[rng.choice(raw.index, 15, replace=False), "traffic_level"] = np.nan
    dups = raw.sample(10, random_state=seed)
    return pd.concat([raw, dups], ignore_index=True)


raw_df = add_data_quality_issues(generate_dataset())
raw_df.to_csv(os.path.join(BASE, "logistics_dataset_raw.csv"), index=False)
print("Raw dataset shape:", raw_df.shape)

# ---------------------------------------------------------------------------
# STEP 2: DATA INSPECTION AND CLEANING
# ---------------------------------------------------------------------------
print("\nData types:\n", raw_df.dtypes)
missing_before = raw_df.isna().sum()
dup_count = int(raw_df.duplicated().sum())
print("\nMissing values before cleaning:\n", missing_before[missing_before > 0])
print("Duplicate rows:", dup_count)

df = raw_df.drop_duplicates().reset_index(drop=True)
invalid = int(((df["distance_km"] <= 0) | (df["dispatch_delay_hours"] < 0)
               | (df[TARGET] <= 0)).sum())
missing_after_dedup = df.isna().sum()
print("Rows after removing duplicates:", len(df), "| invalid values:", invalid)
print("Missing values after de-duplication:\n",
      missing_after_dedup[missing_after_dedup > 0])
df.to_csv(os.path.join(BASE, "logistics_dataset.csv"), index=False)

SUMMARY["raw_rows"] = int(len(raw_df))
SUMMARY["clean_rows"] = int(len(df))
SUMMARY["duplicates_removed"] = dup_count
SUMMARY["invalid_rows"] = invalid
SUMMARY["missing_before"] = {k: int(v) for k, v in missing_before.items()}
SUMMARY["missing_after_dedup"] = {k: int(v) for k, v in
                                  missing_after_dedup.items()}
SUMMARY["median_weight"] = float(df["shipment_weight_kg"].median())
SUMMARY["mode_traffic"] = str(df["traffic_level"].mode()[0])

# ---------------------------------------------------------------------------
# STEP 3: EXPLORATORY DATA ANALYSIS
# ---------------------------------------------------------------------------
desc = df[NUM_COLS + [TARGET]].describe().round(2)
print("\nSummary statistics:\n", desc)
desc.to_csv(os.path.join(BASE, "eda_summary_statistics.csv"))
SUMMARY["describe"] = json.loads(desc.to_json())
corr = df[NUM_COLS + [TARGET]].corr()[TARGET].drop(TARGET).round(3)
print("\nCorrelation with delivery time:\n", corr)
SUMMARY["corr"] = corr.to_dict()
for col in CAT_COLS:
    SUMMARY["mean_by_" + col] = df.groupby(col)[TARGET].mean().round(2).to_dict()
    SUMMARY["count_by_" + col] = df[col].value_counts().to_dict()
df["distance_band"] = pd.cut(df["distance_km"], [0, 100, 300, 600, 2000],
                             labels=["0-100", "100-300", "300-600", "600+"])
df["delay_band"] = pd.cut(df["dispatch_delay_hours"], [-0.01, 1, 3, 20],
                          labels=["0-1 h", "1-3 h", "3+ h"])
SUMMARY["mean_by_distance_band"] = (
    df.groupby("distance_band", observed=True)[TARGET].agg(["count", "mean"])
    .round(2).reset_index().astype(str).values.tolist())
SUMMARY["mean_by_delay_band"] = (
    df.groupby("delay_band", observed=True)[TARGET].agg(["count", "mean"])
    .round(2).reset_index().astype(str).values.tolist())
df = df.drop(columns=["distance_band", "delay_band"])

# ---------------------------------------------------------------------------
# STEP 4: FEATURE / TARGET SEPARATION AND TRAIN-TEST SPLIT
# ---------------------------------------------------------------------------
# shipment_id is only a label, so it is not used as a feature.
X = df[NUM_COLS + CAT_COLS]
y = df[TARGET]
X_train, X_test, y_train, y_test, id_train, id_test = train_test_split(
    X, y, df["shipment_id"], test_size=0.20, random_state=SEED)
print("\nTrain rows:", len(X_train), "| Test rows:", len(X_test))
SUMMARY["n_train"], SUMMARY["n_test"] = len(X_train), len(X_test)

# Preprocessing lives INSIDE the pipeline, so imputation values, scaling and
# encoding categories are learned from the training data only (no leakage).
def make_preprocessor():
    num = Pipeline([("impute", SimpleImputer(strategy="median")),
                    ("scale", StandardScaler())])
    cat = Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                    ("onehot", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("num", num, NUM_COLS), ("cat", cat, CAT_COLS)])


def make_pipe(model):
    return Pipeline([("prep", make_preprocessor()), ("model", model)])


# ---------------------------------------------------------------------------
# STEP 5: MODEL TRAINING (baseline settings)
# ---------------------------------------------------------------------------
models = {
    "Linear Regression": make_pipe(LinearRegression()),
    "Decision Tree": make_pipe(DecisionTreeRegressor(random_state=SEED)),
    "Random Forest": make_pipe(RandomForestRegressor(
        n_estimators=200, random_state=SEED, n_jobs=-1)),
}
for name, pipe in models.items():
    pipe.fit(X_train, y_train)

# ---------------------------------------------------------------------------
# STEP 6: HYPERPARAMETER TUNING (grid search with 5-fold CV on training data)
# ---------------------------------------------------------------------------
kf = KFold(n_splits=5, shuffle=True, random_state=SEED)
dt_grid = {"model__max_depth": [3, 5, 7, 10, None],
           "model__min_samples_leaf": [1, 5, 10, 20]}
rf_grid = {"model__n_estimators": [100, 300],
           "model__max_depth": [6, 10, None],
           "model__min_samples_leaf": [1, 3, 5]}
tuned = {}
for label, pipe, grid in [
        ("Decision Tree (tuned)", models["Decision Tree"], dt_grid),
        ("Random Forest (tuned)", models["Random Forest"], rf_grid)]:
    gs = GridSearchCV(clone(pipe), grid, cv=kf, n_jobs=-1,
                      scoring="neg_root_mean_squared_error")
    gs.fit(X_train, y_train)
    tuned[label] = gs.best_estimator_
    SUMMARY["best_params_" + label] = {k.replace("model__", ""): (
        None if v is None else int(v)) for k, v in gs.best_params_.items()}
    print(label, "best params:", gs.best_params_,
          "| CV RMSE:", round(-gs.best_score_, 3))
models.update(tuned)

# ---------------------------------------------------------------------------
# STEP 7: EVALUATION ON THE SAME TEST SET + 5-FOLD CROSS-VALIDATION
# ---------------------------------------------------------------------------
def rmse(a, b):
    return float(np.sqrt(mean_squared_error(a, b)))


rows, cv_rows, preds = [], [], {}
for name, pipe in models.items():
    p = pipe.predict(X_test)
    preds[name] = p
    train_r2 = r2_score(y_train, pipe.predict(X_train))
    cv = cross_validate(clone(pipe), X_train, y_train, cv=kf,
                        scoring=["neg_mean_absolute_error",
                                 "neg_root_mean_squared_error", "r2"])
    rows.append({"Model": name,
                 "MAE": mean_absolute_error(y_test, p),
                 "RMSE": rmse(y_test, p), "R2": r2_score(y_test, p),
                 "Train_R2": train_r2})
    cv_rows.append({"Model": name,
                    "CV_MAE_mean": -cv["test_neg_mean_absolute_error"].mean(),
                    "CV_RMSE_mean": -cv["test_neg_root_mean_squared_error"].mean(),
                    "CV_RMSE_std": cv["test_neg_root_mean_squared_error"].std(),
                    "CV_R2_mean": cv["test_r2"].mean()})
results = pd.DataFrame(rows).merge(pd.DataFrame(cv_rows), on="Model")

# Model selection uses cross-validation on TRAINING data only (not test data).
best_name = results.loc[results["CV_RMSE_mean"].idxmin(), "Model"]
results["Selected"] = results["Model"] == best_name
results = results.round(4)
results.to_csv(os.path.join(BASE, "model_evaluation_results.csv"), index=False)
print("\n", results.to_string(index=False))
print("\nSelected model (lowest CV RMSE):", best_name)
SUMMARY["results"] = results.to_dict(orient="records")
SUMMARY["best_name"] = best_name
best_model = models[best_name]
rf_model = models["Random Forest (tuned)"]
joblib.dump(best_model, os.path.join(BASE, "best_model.joblib"))

# ---------------------------------------------------------------------------
# STEP 8: PREDICTIONS AND ERROR ANALYSIS
# ---------------------------------------------------------------------------
best_pred = preds[best_name]
pred_df = pd.DataFrame({"shipment_id": id_test.values,
                        "actual_hours": y_test.values.round(2),
                        "predicted_hours": best_pred.round(2)})
pred_df["error_hours"] = (pred_df["predicted_hours"] - pred_df["actual_hours"]).round(2)
pred_df["abs_error_hours"] = pred_df["error_hours"].abs().round(2)
for name in models:
    pred_df["pred_" + name.replace(" ", "_").replace("(", "").replace(")", "")] = \
        preds[name].round(2)
pred_df.to_csv(os.path.join(BASE, "predictions.csv"), index=False)
resid = y_test.values - best_pred
SUMMARY["resid_mean"] = float(resid.mean())
SUMMARY["resid_std"] = float(resid.std())
SUMMARY["within_2h"] = float((np.abs(resid) <= 2).mean() * 100)
SUMMARY["within_3h"] = float((np.abs(resid) <= 3).mean() * 100)
SUMMARY["max_abs_err"] = float(np.abs(resid).max())
SUMMARY["sample_predictions"] = pred_df.head(10)[
    ["shipment_id", "actual_hours", "predicted_hours", "error_hours"]
].values.tolist()
err_df = X_test.copy()
err_df["abs_err"] = np.abs(resid)
err_df["dist_band"] = pd.cut(err_df["distance_km"], [0, 100, 300, 600, 2000],
                             labels=["0-100", "100-300", "300-600", "600+"])
SUMMARY["mae_by_weather"] = err_df.groupby("weather_condition")["abs_err"] \
    .mean().round(2).to_dict()
SUMMARY["mae_by_traffic"] = err_df.groupby("traffic_level")["abs_err"] \
    .mean().round(2).to_dict()
SUMMARY["mae_by_distband"] = err_df.groupby("dist_band", observed=True)[
    "abs_err"].mean().round(2).astype(float).to_dict()
SUMMARY["mae_by_distband"] = {str(k): v for k, v in
                              SUMMARY["mae_by_distband"].items()}

# Feature importance of the tuned Random Forest (tree-based model)
feat_names = rf_model.named_steps["prep"].get_feature_names_out()
imp = pd.DataFrame({"feature": [f.split("__")[1] for f in feat_names],
                    "importance": rf_model.named_steps["model"]
                    .feature_importances_}).sort_values("importance",
                                                        ascending=False)
imp.round(4).to_csv(os.path.join(BASE, "feature_importance.csv"), index=False)
SUMMARY["importance"] = imp.round(4).values.tolist()
print("\nTop features (tuned Random Forest):\n", imp.head(8).round(4))
if best_name == "Linear Regression":
    coef = best_model.named_steps["model"].coef_
    lr_names = best_model.named_steps["prep"].get_feature_names_out()
    SUMMARY["lr_coefs"] = {n.split("__")[1]: float(c)
                           for n, c in zip(lr_names, coef)}
    SUMMARY["lr_intercept"] = float(best_model.named_steps["model"].intercept_)

# Simple sensitivity check: model-predicted effect of +1 h delay / +100 km
base_p = best_model.predict(X_test)
X_d = X_test.copy(); X_d["dispatch_delay_hours"] += 1
X_k = X_test.copy(); X_k["distance_km"] += 100
SUMMARY["effect_plus1h_delay"] = float((best_model.predict(X_d) - base_p).mean())
SUMMARY["effect_plus100km"] = float((best_model.predict(X_k) - base_p).mean())
for lab, col, vals in [("traffic", "traffic_level", ["Low", "Medium", "High"]),
                       ("weather", "weather_condition", ["Clear", "Rain", "Storm"])]:
    eff = {}
    for v in vals:
        Xv = X_test.copy(); Xv[col] = v
        eff[v] = float(best_model.predict(Xv).mean())
    SUMMARY["all_shipments_" + lab] = eff

# ---------------------------------------------------------------------------
# STEP 9: SIX VISUALIZATIONS
# ---------------------------------------------------------------------------
plt.rcParams.update({"figure.dpi": 150, "font.size": 10})

# Figure 1: distribution of delivery times
plt.figure(figsize=(7, 4.2))
plt.hist(df[TARGET], bins=30, color="#2f6f9f", edgecolor="white")
plt.axvline(df[TARGET].mean(), color="red", ls="--",
            label=f"Mean = {df[TARGET].mean():.1f} h")
plt.xlabel("Actual delivery time (hours)"); plt.ylabel("Number of shipments")
plt.title("Figure 1: Distribution of Delivery Times"); plt.legend()
plt.tight_layout(); plt.savefig(os.path.join(VIZ, "fig1_delivery_time_distribution.png")); plt.close()

# Figure 2: distance versus delivery time (coloured by traffic)
plt.figure(figsize=(7, 4.2))
for lvl, c in [("Low", "#2e8b57"), ("Medium", "#e0a800"), ("High", "#c0392b")]:
    s = df[df["traffic_level"] == lvl]
    plt.scatter(s["distance_km"], s[TARGET], s=10, alpha=0.6, color=c, label=lvl)
m, b = np.polyfit(df["distance_km"], df[TARGET], 1)
xs = np.linspace(df["distance_km"].min(), df["distance_km"].max(), 50)
plt.plot(xs, m * xs + b, color="black", lw=1.5, label="Trend line")
plt.xlabel("Distance (km)"); plt.ylabel("Actual delivery time (hours)")
plt.title("Figure 2: Distance vs Delivery Time (by traffic level)")
plt.legend(title="Traffic"); plt.tight_layout()
plt.savefig(os.path.join(VIZ, "fig2_distance_vs_delivery_time.png")); plt.close()
SUMMARY["trend_slope_per_km"] = float(m)

# Figure 3: actual versus predicted (selected model, test set)
plt.figure(figsize=(5.6, 5.4))
plt.scatter(y_test, best_pred, s=14, alpha=0.65, color="#2f6f9f")
lim = [min(y_test.min(), best_pred.min()), max(y_test.max(), best_pred.max())]
plt.plot(lim, lim, "r--", label="Perfect prediction")
plt.xlabel("Actual delivery time (hours)"); plt.ylabel("Predicted (hours)")
plt.title(f"Figure 3: Actual vs Predicted\n({best_name}, test set)")
plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(VIZ, "fig3_actual_vs_predicted.png")); plt.close()

# Figure 4: residual (error) distribution
plt.figure(figsize=(7, 4.2))
plt.hist(resid, bins=25, color="#6a5acd", edgecolor="white")
plt.axvline(0, color="red", ls="--")
plt.xlabel("Residual = actual - predicted (hours)"); plt.ylabel("Count")
plt.title(f"Figure 4: Residual Distribution ({best_name})")
plt.tight_layout(); plt.savefig(os.path.join(VIZ, "fig4_residual_distribution.png")); plt.close()

# Figure 5: model performance comparison
fig, ax = plt.subplots(figsize=(8, 4.4))
idx = np.arange(len(results)); w = 0.38
ax.bar(idx - w / 2, results["MAE"], w, label="MAE", color="#2f6f9f")
ax.bar(idx + w / 2, results["RMSE"], w, label="RMSE", color="#e07b39")
ax.set_xticks(idx)
ax.set_xticklabels([n.replace(" (", "\n(") for n in results["Model"]], fontsize=8)
ax.set_ylabel("Error (hours) - lower is better")
ax.set_title("Figure 5: Model Performance Comparison (test set)"); ax.legend()
plt.tight_layout(); plt.savefig(os.path.join(VIZ, "fig5_model_comparison.png")); plt.close()

# Figure 6: feature importance (tuned Random Forest)
top = imp.head(10).iloc[::-1]
plt.figure(figsize=(7, 4.4))
plt.barh(top["feature"], top["importance"], color="#2e8b57")
plt.xlabel("Importance (share of total)")
plt.title("Figure 6: Feature Importance (Random Forest, tuned)")
plt.tight_layout(); plt.savefig(os.path.join(VIZ, "fig6_feature_importance.png")); plt.close()

# ---------------------------------------------------------------------------
# STEP 10: WHAT-IF OPTIMIZATION ANALYSIS (simulated scenarios)
# ---------------------------------------------------------------------------
SLA_HOURS = 36.0                # assumed promised delivery window
COST_PER_SHIPMENT_HOUR = 25.0   # ASSUMED holding/handling cost (INR per hour)


def scenario_inputs(X0, base_pred):
    """Return a dict of modified copies of the test features."""
    sc = {}
    a = X0.copy(); a["dispatch_delay_hours"] = a["dispatch_delay_hours"].clip(upper=1.0)
    sc["S1: Cap dispatch delay at 1 h (all)"] = a
    b = X0.copy(); b["dispatch_delay_hours"] = b["dispatch_delay_hours"] * 0.5
    sc["S2: Halve dispatch delay (all)"] = b
    c = X0.copy()
    risky = base_pred >= np.percentile(base_pred, 80)      # top 20% predicted
    c.loc[risky, "dispatch_delay_hours"] = c.loc[risky, "dispatch_delay_hours"].clip(upper=0.5)
    sc["S3: Priority dispatch (<=0.5 h) for top-20% risk"] = c
    d = X0.copy(); d.loc[d["traffic_level"] == "High", "traffic_level"] = "Medium"
    sc["S4: Re-time High-traffic shipments to Medium"] = d
    e = b.copy(); e.loc[e["traffic_level"] == "High", "traffic_level"] = "Medium"
    sc["S5: Combined S2 + S4"] = e
    return sc


opt_rows = []
for mname, mdl in [(best_name, best_model), ("Random Forest (tuned)", rf_model)]:
    if mname == "Random Forest (tuned)" and best_name == mname:
        continue
    base = mdl.predict(X_test)
    opt_rows.append({"Model": mname, "Scenario": "Baseline (no change)",
                     "Mean_predicted_hours": base.mean(),
                     "Change_hours": 0.0, "Change_percent": 0.0,
                     "Predicted_SLA_breaches": int((base > SLA_HOURS).sum()),
                     "Hours_saved_total": 0.0, "Est_cost_saving_INR": 0.0})
    for sname, Xs in scenario_inputs(X_test, base).items():
        p = mdl.predict(Xs)
        saved = float((base - p).sum())
        opt_rows.append({"Model": mname, "Scenario": sname,
                         "Mean_predicted_hours": p.mean(),
                         "Change_hours": p.mean() - base.mean(),
                         "Change_percent": 100 * (p.mean() - base.mean()) / base.mean(),
                         "Predicted_SLA_breaches": int((p > SLA_HOURS).sum()),
                         "Hours_saved_total": saved,
                         "Est_cost_saving_INR": saved * COST_PER_SHIPMENT_HOUR})
opt = pd.DataFrame(opt_rows).round(3)
opt.to_csv(os.path.join(BASE, "optimization_results.csv"), index=False)
print("\nWhat-if results (SIMULATED, model-predicted):\n", opt.to_string(index=False))
SUMMARY["optimization"] = opt.to_dict(orient="records")
SUMMARY["sla"], SUMMARY["cost_rate"] = SLA_HOURS, COST_PER_SHIPMENT_HOUR
SUMMARY["actual_breaches_test"] = int((y_test > SLA_HOURS).sum())

with open(os.path.join(BASE, "results_summary.json"), "w") as f:
    json.dump(SUMMARY, f, indent=1, default=str)
print("\nDone. Files saved in:", BASE)
